<?php

namespace Ion\ProductBanner\Controller\Product;

use Magento\Framework\App\Action\Action;

class Index extends Action
{
    public function execute()
    {
        echo "Fuck off!";
    }
}